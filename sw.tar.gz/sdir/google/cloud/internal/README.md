# Implementation Details for google/cloud/\*.{h,cc}

This directory contains implementation details for the files in `google/cloud/`.
All the code in this directory, is subject to change without notice.
